#ifndef BST_NODE
#define BST_NODE
#include <iostream>
#include <cctype>
#include <cstring>
#include "family.h"



class rb_node
{
	public:
		rb_node();
		rb_node *& go_right();
		rb_node *& go_left();
		rb_node *& go_parent();

		void connect_parent(rb_node * connect);
		void connect_left(rb_node * connect);
		void connect_right(rb_node * connect);
		void display_list();
		

		bool flag_is_red();
		void set_flag(bool color);
	private:
		rb_node * left;
		rb_node * right;
		rb_node * parent;
		bool flag;
		lll_node head;
};
#endif
