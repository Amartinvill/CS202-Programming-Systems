#include "bst_node.h"
using namespace std;

rb_node::rb_node():left(NULL), right(NULL), flag(true)
{}

rb_node *& rb_node::go_right()
{

	return right;
}

rb_node *& rb_node::go_left()
{
	return left;
}

rb_node *& rb_node::go_parent()
{
	return parent;
}

void rb_node::connect_parent(rb_node * connect)
{
	parent = connect;
}

void rb_node::connect_left(rb_node * connect)
{
	left = connect;
}

void rb_node::connect_right(rb_node * connect)
{
	right = connect;
}

bool rb_node::flag_is_red()
{
	return flag;
}

void rb_node::set_flag(bool color)
{
	flag = color;
}

void rb_node::display_list()
{
	head.display_all();
}
