/*
Angel Martinez
CS202
Assignment #3
*/
#include "bst_node.h"

//the purpose of this class is to be able to have the right
//prototypes to was can create a red black tree balance tree
class balance_tree
{
	public:
		//constructor
		balance_tree();
		//copy constructor
		balance_tree(const balance_tree & copy_from);
		~balance_tree();
		int display_all();
	
	protected:
		rb_node * root;

		int remove_all(rb_node *& root);
		int deep_copy(rb_node *& dest, rb_node * root, rb_node * parent);
		int display_all(rb_node * root);
		void insert_case_1(rb_node * root);
		void insert_case_2(rb_node * root);
		void insert_case_3(rb_node * root);
		void insert_case_4(rb_node * root);
		void insert_case_5(rb_node * root);
		rb_node * uncle(rb_node * root);
		rb_node * grandpa(rb_node * root);
		void rotate_left(rb_node * ratating_node );
};
